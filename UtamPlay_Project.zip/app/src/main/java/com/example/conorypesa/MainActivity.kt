package com.example.conorypesa

import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var postAdapter: PostAdapter
    private val posts = mutableListOf<Post>()

    // Admin password (default). You can change this before building.
    private val adminPassword = "admin123"

    // Activity result launcher for picking a single video
    private val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            // Add new post with picked video URI
            posts.add(0, Post("Admin", "Uploaded video", it.toString(), 0))
            postAdapter.notifyItemInserted(0)
            recyclerView.scrollToPosition(0)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_ConoryPesa_Dark)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        postAdapter = PostAdapter(posts)
        recyclerView.adapter = postAdapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Sample remote videos
        posts.add(Post("Jamson", "Hii ni video ya kwanza", "https://storage.googleapis.com/exoplayer-test-media-0/BigBuckBunny.mp4"))
        posts.add(Post("Alice", "Video ya pili", "https://storage.googleapis.com/exoplayer-test-media-0/ElephantsDream.mp4"))
        posts.add(Post("Moses", "Video ya tatu", "https://storage.googleapis.com/exoplayer-test-media-0/Sintel-1024-surround.mp4"))
        postAdapter.notifyDataSetChanged()

        val btnUpload: Button = findViewById(R.id.btnUpload)
        btnUpload.setOnClickListener {
            showAdminPasswordDialog()
        }
    }

    private fun showAdminPasswordDialog() {
        val editText = EditText(this)
        editText.hint = "Enter admin password"
        AlertDialog.Builder(this)
            .setTitle("Admin login")
            .setView(editText)
            .setPositiveButton("OK") { dialog, _ ->
                val input = editText.text.toString()
                if (input == adminPassword) {
                    // launch picker for videos
                    pickVideo.launch("video/*")
                } else {
                    AlertDialog.Builder(this)
                        .setMessage("Wrong password")
                        .setPositiveButton("OK", null)
                        .show()
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
