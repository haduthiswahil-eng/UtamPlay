package com.example.conorypesa

data class Post(
    val username: String,
    val description: String,
    val videoUrl: String,
    var likes: Int = 0
)
