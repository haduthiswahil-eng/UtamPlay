package com.example.conorypesa

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.ui.PlayerView

class PostAdapter(private val posts: List<Post>) : RecyclerView.Adapter<PostAdapter.PostViewHolder>() {

    inner class PostViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val playerView: PlayerView = view.findViewById(R.id.playerView)
        val tvUsername: TextView = view.findViewById(R.id.tvUsername)
        val tvDescription: TextView = view.findViewById(R.id.tvDescription)
        val btnLike: ImageButton = view.findViewById(R.id.btnLike)
        val tvLikes: TextView = view.findViewById(R.id.tvLikes)
        var player: ExoPlayer? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_post, parent, false)
        return PostViewHolder(view)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post = posts[position]
        holder.tvUsername.text = post.username
        holder.tvDescription.text = post.description
        holder.tvLikes.text = post.likes.toString()

        // release previous player if any
        holder.player?.release()

        // build new player
        holder.player = ExoPlayer.Builder(holder.itemView.context).build()
        holder.playerView.player = holder.player

        // create media item from either remote url or content uri
        val uri = Uri.parse(post.videoUrl)
        val mediaItem = MediaItem.fromUri(uri)
        holder.player?.setMediaItem(mediaItem)
        holder.player?.prepare()
        holder.player?.playWhenReady = true

        holder.btnLike.setOnClickListener {
            post.likes += 1
            holder.tvLikes.text = post.likes.toString()
        }
    }

    override fun getItemCount(): Int = posts.size

    override fun onViewRecycled(holder: PostViewHolder) {
        super.onViewRecycled(holder)
        holder.player?.release()
        holder.player = null
    }
}
