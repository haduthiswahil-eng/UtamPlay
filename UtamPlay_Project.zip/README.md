# UtamPlay - Android project (template)

This project is a simple TikTok-like Android app with an **admin-only upload** feature.

**Features**
- Home feed that streams sample videos using ExoPlayer.
- Admin-only upload button protected by a password. Default password: `admin123`.
- Uploaded videos are added to the top of the feed (local only).

**How to build locally**
1. Download and extract this folder.
2. Open the project in Android Studio (`File -> Open` and select the folder).
3. Let Gradle sync. If prompted to update Gradle plugin or Kotlin, accept recommended updates.
4. Build APK: `Build -> Build Bundle(s) / APK(s) -> Build APK(s)`.
5. The APK will be in `app/build/outputs/apk/debug/app-debug.apk`.

**How to build using GitHub Actions (automatic)**
1. Create a new GitHub repository and push this project to it (main branch).
2. On push to `main`, GitHub Actions will run the workflow and produce an APK artifact.
3. Go to the Actions tab in your repo, open the workflow run, and download the `app-debug-apk` artifact.

**Change admin password**
- Edit `MainActivity.kt` and change `adminPassword` value before building.

**Notes**
- This template streams remote sample videos. When uploading from device gallery, the video is stored as a content URI and played locally.
- If you want uploaded videos to persist across app restarts, integrate local database / file copy logic or cloud storage (Firebase).
